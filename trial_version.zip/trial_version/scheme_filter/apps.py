from django.apps import AppConfig


class SchemeFilterConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'scheme_filter'


# class FormConfig(AppConfig):
#     default_auto_field = 'django.db.models.BigAutoField'
#     name = 'scheme_filter'

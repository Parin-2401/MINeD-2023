from django.shortcuts import render, redirect
from django.http import HttpResponse

from .models import *
from .filters import SchemeDataFilter
from twilio.rest import Client
import random
# from scheme_filter.models import models

# Create your views here.

def home(request):
    movies = SchemeData.objects.all()
    myFilter = SchemeDataFilter(request.GET, queryset=movies)
    movies = myFilter.qs
    context = {
        'myFilter': myFilter,
        'movies': movies,
    }
    return render(request, 'index.html', context)

def index(request):
    return render(request, 'index1.html')


def health(request):
    return render(request, 'health.html')


def social(request):
    return render(request, 'social.html')


def contact(request):
    return render(request, 'contact.html')


def content(request):
    return render(request, 'content.html')


def pre_verification(request):
    # if request.method == "POST":
    #     print("This is post")

    a = request.POST

    value = request.POST.get('email1', '')
    value2 = request.POST.get('uname', '')
    value3 = request.POST.get('mobile', '')
    value4 = request.POST.get('city', '')
    value5 = request.POST.get('pincode', '')
    value6 = request.POST.get('address', '')
    value7 = request.POST.get('age', '')
    value8 = request.POST.get('gender', '')
    value9 = request.POST.get('income', '')
    value10 = request.POST.get('bank', '')
    value11 = request.POST.get('category', '')

    # print(request.POST)
    # print(">> Email: ",value)
    # print(">> Username: ",value2)
    # print(">> Mobile: ",value3)
    # print(">> City: ",value4)
    # print(">> Pincode: ",value5)

    ins = Form(uname=value2, email=value, mobile=value3, city=value4, address=value6, pincode=value5, age=value7, gender=value8, income=value9, bank=value10, category=value11)
    ins.save()

    return render(request, 'index2.html', {'a': a})


def save(self, *args, **kwargs):
    # value = random.randint(1000, 9999)
    value = random.randint(1000, 9999)

    account_sid = 'AC3a13a922706360e439509be1ae650f05'
    auth_token = 'a2be1bf9ef5befc80463f0141727631d'
    client = Client(account_sid, auth_token)

    message = client.messages.create(
        # body='Hi there',
        body=f'Your otp for Aadhar card verification is {value}',
        from_='+13157848329',
        to='+917227973040'
    )
    print(message.sid)
    ins = Otp(value=value)
    ins.save()
    return super().save(*args, **kwargs)

def social1(request):
    return render(request, 'social/social1.html')
def social2(request):
    return render(request, 'social/social2.html')
def social3(request):
    return render(request, 'social/social3.html')
def social4(request):
    return render(request, 'social/social4.html')
def social5(request):
    return render(request, 'social/social5.html')
def social6(request):
    return render(request, 'social/social6.html')
def social7(request):
    return render(request, 'social/social7.html')
def social8(request):
    return render(request, 'social/social8.html')
def social9(request):
    return render(request, 'social/social9.html')
def social10(request):
    return render(request, 'social/social10.html')
def health1(request):
    return render(request, 'health1.html')
def aadhar(request):
    return render(request, 'aadhar.html')
def health2(request):
    return render(request, 'health/health2.html')
def health3(request):
    return render(request, 'health/health3.html')
def health4(request):
    return render(request, 'health/health4.html')
def health5(request):
    return render(request, 'health/health5.html')
def health6(request):
    return render(request, 'health/health6.html')
def health7(request):
    return render(request, 'health/health7.html')
def health8(request):
    return render(request, 'health/health8.html')
def health9(request):
    return render(request, 'health/health9.html')
def health10(request):
    return render(request, 'health/health10.html')

# def health1(request):
#     return render(request, 'health/health1.html')




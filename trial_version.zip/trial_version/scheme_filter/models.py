from django.db import models

# Create your models here.
class SchemeData(models.Model):
    scheme_name = models.CharField(max_length=200, null=True)
    gender = models.CharField(max_length=200, null=True)
    residence_area = models.CharField(max_length=200, null=True)
    age_group = models.CharField(max_length=200, null=True)
    reservation = models.CharField(max_length=200, null=True)
    minority = models.CharField(max_length=200, null=True)
    student = models.CharField(max_length=200, null=True)
    annual_income = models.CharField(max_length=200, null=True)
    bpl = models.CharField(max_length=200, null=True)
    date_created = models.DateTimeField(auto_now_add=True, null=True)

    def __str__(self):
        return self.scheme_name


class Form(models.Model):
    uname = models.CharField(max_length=50, null=True)
    email = models.EmailField(max_length=50, null=True)
    mobile = models.CharField(max_length=10, null=True)
    city = models.CharField(max_length=20, null=True)
    pincode = models.CharField(max_length=6, null=True)
    address = models.CharField(max_length=100, null=True)
    age = models.CharField(max_length=3, null=True)
    gender = models.CharField(max_length=1, null=True)
    category = models.CharField(max_length=10, null=True)
    income = models.CharField(max_length=15, null=True)
    bank = models.CharField(max_length=17, null=True)


    # def __str__(self):
    #     return self.uname

class Otp(models.Model):
    result = models.PositiveIntegerField()
    value = models.CharField(max_length=4, null=True)

    def __str__(self):
        return str(self.result)


from django.contrib import admin

# Register your models here.

from .models import *

admin.site.register(SchemeData)
admin.site.register(Form)
admin.site.register(Otp)

import django_filters
from .models import SchemeData
from django_filters import CharFilter

class SchemeDataFilter(django_filters.FilterSet):
    gender = CharFilter(field_name="gender", lookup_expr="icontains")
    residence_area = CharFilter(field_name="residence_area", lookup_expr="icontains")
    age_group = CharFilter(field_name="age_group", lookup_expr="icontains")
    reservation = CharFilter(field_name="reservation", lookup_expr="icontains")
    minority = CharFilter(field_name="minority", lookup_expr="icontains")
    student = CharFilter(field_name="student", lookup_expr="icontains")
    annual_income = CharFilter(field_name="annual_income", lookup_expr="icontains")
    bpl = CharFilter(field_name="bpl", lookup_expr="icontains")

    class Meta:
        model = SchemeData
        # fields = '__all__'
        fields = ['gender', 'residence_area','age_group','reservation','minority','student','annual_income','bpl']
